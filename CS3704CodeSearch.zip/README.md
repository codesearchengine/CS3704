This project requires grunt to work.

To get grunt set up, first install NodeJS from https://nodejs.org/en/

Then open a command window and do `npm install -g grunt-cli`

This will install the Grunt command line. Once that's done, navigate in the command window to the project folder, and do `npm install grunt`

This will install Grunt itself. After that, do `npm install grunt-contrib-concat --save-dev` and `npm install grunt-contrib-uglify --save-dev`

After that, you can do `grunt concat` and open index.html to run the project.